function setPixelColor(pixel)
{
  pixel.style.backgroundColor =penColor;
}
var penColor = 'black';
function setPenColor(pen)
{
  penColor= pen;
}